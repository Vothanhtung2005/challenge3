package com.example.challenge3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;

import java.util.Random;

public class GameActivity extends AppCompatActivity {

    TextView tvScore, tvLife, tvTimer, tvQuestion;
    EditText etAnswer;
    Button btnOK, btnNext;

    int score = 0, life = 3;
    CountDownTimer timer;
    int correctAnswer;
    String operation = "addition"; // default

    void generateQuestion() {
        int num1 = new Random().nextInt(100);
        int num2 = new Random().nextInt(100);

        switch (operation) {
            case "addition":
                correctAnswer = num1 + num2;
                tvQuestion.setText(num1 + " + " + num2);
                break;
            case "subtraction":
                // Đảm bảo không âm
                if (num2 > num1) {
                    int temp = num1;
                    num1 = num2;
                    num2 = temp;
                }
                correctAnswer = num1 - num2;
                tvQuestion.setText(num1 + " - " + num2);
                break;
            case "multiplication":
                num1 = new Random().nextInt(20); // Giới hạn để không quá lớn
                num2 = new Random().nextInt(10);
                correctAnswer = num1 * num2;
                tvQuestion.setText(num1 + " × " + num2);
                break;
        }
    }

    void startTimer() {
        timer = new CountDownTimer(60000, 1000) {
            public void onTick(long millisUntilFinished) {
                tvTimer.setText("Timer: " + millisUntilFinished / 1000);
            }

            public void onFinish() {
                gameOver();
            }
        }.start();
    }

    void gameOver() {
        if (timer != null) {
            timer.cancel();
        }
        Intent intent = new Intent(GameActivity.this, ResultActivity.class);
        intent.putExtra("score", score);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        tvScore = findViewById(R.id.tvScore);
        tvLife = findViewById(R.id.tvLife);
        tvTimer = findViewById(R.id.tvTimer);
        tvQuestion = findViewById(R.id.tvQuestion);
        etAnswer = findViewById(R.id.etAnswer);
        btnOK = findViewById(R.id.btnOK);
        btnNext = findViewById(R.id.btnNext);

        // Nhận phép toán từ MainActivity
        operation = getIntent().getStringExtra("operation");
        if (operation == null) operation = "addition"; // fallback

        startTimer();
        generateQuestion();

        btnOK.setOnClickListener(v -> {
            String answerText = etAnswer.getText().toString().trim();
            if (!answerText.isEmpty()) {
                try {
                    int userAnswer = Integer.parseInt(answerText);
                    if (userAnswer == correctAnswer) {
                        score += 10;
                        tvScore.setText("Score: " + score);
                        tvQuestion.setText("Correct!");
                    } else {
                        life--;
                        tvLife.setText("Life: " + life);
                        tvQuestion.setText("Wrong! Correct answer: " + correctAnswer);
                        if (life == 0) {
                            gameOver();
                            return;
                        }
                    }
                } catch (NumberFormatException e) {
                    etAnswer.setError("Please enter a valid number");
                }
            } else {
                etAnswer.setError("Answer cannot be empty");
            }
            btnOK.setEnabled(false); // Ngăn người dùng nhấn OK nhiều lần
        });


        btnNext.setOnClickListener(v -> {
            etAnswer.setText("");
            generateQuestion();
            btnOK.setEnabled(true); // Cho phép trả lời lại
        });

    }
}
