package com.example.challenge3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    TextView tvFinalScore, tvCongratulation;
    Button btnPlayAgain, btnExit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        tvFinalScore = findViewById(R.id.tvFinalScore);
        tvCongratulation = findViewById(R.id.tvCongratulation);
        btnPlayAgain = findViewById(R.id.btnPlayAgain);
        btnExit = findViewById(R.id.btnExit);

        int finalScore = getIntent().getIntExtra("score", 0);
        String operation = getIntent().getStringExtra("operation"); // Nhận phép toán

        tvFinalScore.setText("Score: " + finalScore);

        // Tuỳ điểm để hiển thị lời chúc
        if (finalScore >= 100) {
            tvCongratulation.setText("Excellent!");
        } else if (finalScore >= 50) {
            tvCongratulation.setText("Good job!");
        } else {
            tvCongratulation.setText("Keep practicing!");
        }

        btnPlayAgain.setOnClickListener(v -> {
            Intent intent = new Intent(ResultActivity.this, GameActivity.class);
            intent.putExtra("operation", operation); // Truyền lại phép toán
            startActivity(intent);
            finish();
        });

        btnExit.setOnClickListener(v -> finishAffinity()); // Thoát toàn bộ app
    }
}
